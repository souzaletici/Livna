const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('livna_db', 'usuario', 'senha', {
  host: 'localhost',
  dialect: 'mysql'
});

sequelize.authenticate()
  .then(() => console.log('Banco conectado com sucesso!'))
  .catch(err => console.error('Erro ao conectar:', err));

module.exports = sequelize;
