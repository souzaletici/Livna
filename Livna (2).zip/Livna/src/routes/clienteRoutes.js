const express = require('express');
const router = express.Router();
const Cliente = require('../models/Cliente');

// Listar clientes
router.get('/', async (req, res) => {
  const clientes = await Cliente.findAll();
  res.json(clientes);
});

// Criar cliente
router.post('/', async (req, res) => {
  try {
    const novo = await Cliente.create(req.body);
    res.status(201).json(novo);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
});

module.exports = router;