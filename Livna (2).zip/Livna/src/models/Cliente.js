const { DataTypes } = require('sequelize');
const sequelize = require('.../config/database');

const Cliente = sequelize.define('Cliente', {
  ID_Cliente: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  Nome: { type: DataTypes.STRING(100), allowNull: false },
  CPF: { type: DataTypes.STRING(11), unique: true, allowNull: false },
  Email: { type: DataTypes.STRING(100) },
  Telefone: { type: DataTypes.STRING(20) },
  Cidade: { type: DataTypes.STRING(50) },
  Estado: { type: DataTypes.STRING(2) },
  CEP: { type: DataTypes.STRING(8) },
  Data_Cadastro: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
  Historico_Compras: { type: DataTypes.TEXT }
}, {
  tableName: 'Cliente',
  timestamps: false
});

module.exports = Cliente;