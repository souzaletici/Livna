import express from 'express';
import dotenv from 'dotenv';
import { sequelize } from './models/index.js';

// Importa as rotas
import clienteRoutes from './routes/clienteRoutes.js';
import produtoRoutes from './routes/produtoRoutes.js';
import pedidoRoutes from './routes/pedidoRoutes.js';
import pagamentoRoutes from './routes/pagamentoRoutes.js';
import estoqueRoutes from './routes/estoque.js';
import itemPedidoRoutes from './routes/itemPedidoRoutes.js';

dotenv.config();

const app = express();

// Middleware
app.use(express.json());

// Usa as rotas
app.use('/api/clientes', clienteRoutes);
app.use('/api/produtos', produtoRoutes);
app.use('/api/pedidos', pedidoRoutes);
app.use('/api/pagamentos', pagamentoRoutes);
app.use('/api/estoque', estoqueRoutes);
app.use('/api/itens-pedido', itemPedidoRoutes);

// Testa conexão com o banco
sequelize.authenticate()
  .then(() => console.log('✅ Conectado ao banco de dados!'))
  .catch(err => console.error('❌ Erro de conexão:', err));

// Inicia o servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 API rodando na porta ${PORT}`));