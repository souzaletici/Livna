import { DataTypes } from 'sequelize';
import sequelize from '../assets/config/dataBase.js';

const Cliente = sequelize.define('Cliente', {
  ID_Cliente: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  Nome: { type: DataTypes.STRING(100), allowNull: false },
  CPF: { type: DataTypes.CHAR(11), unique: true, allowNull: false },
  Email: { type: DataTypes.STRING(100) },
  Telefone: { type: DataTypes.STRING(20) },
  Cidade: { type: DataTypes.STRING(50) },
  Estado: { type: DataTypes.CHAR(2) },
  CEP: { type: DataTypes.CHAR(8) },
  Data_Cadastro: { type: DataTypes.DATEONLY, defaultValue: DataTypes.NOW },
  Historico_Compras: { type: DataTypes.TEXT },
});

export default Cliente;