import { DataTypes } from 'sequelize';
import sequelize from '../assets/config/dataBase.js';
import Pedido from './Pedido.js';

const Pagamento = sequelize.define('Pagamento', {
  ID_Pagamento: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  Metodo_Pagamento: { type: DataTypes.ENUM('Cartão', 'Boleto', 'Pix'), allowNull: false },
  Status_Pagamento: { type: DataTypes.ENUM('Pendente', 'Pago'), defaultValue: 'Pendente' },
  Valor_Pago: { type: DataTypes.DECIMAL(10,2), allowNull: false },
});

// Relacionamento 1:1 com Pedido
Pedido.hasOne(Pagamento, { foreignKey: 'ID_Pedido', onDelete: 'CASCADE' });
Pagamento.belongsTo(Pedido, { foreignKey: 'ID_Pedido' });

export default Pagamento;