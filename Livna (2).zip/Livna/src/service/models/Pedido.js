import { DataTypes } from 'sequelize';
import sequelize from '../assets/config/dataBase.js';
import Cliente from './Cliente.js';

const Pedido = sequelize.define('Pedido', {
  ID_Pedido: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  Data_Pedido: { type: DataTypes.DATEONLY, defaultValue: DataTypes.NOW },
  Status: { type: DataTypes.ENUM('Em andamento', 'Enviado', 'Entregue'), defaultValue: 'Em andamento' },
  Total_Pedido: { type: DataTypes.DECIMAL(10,2) },
});

// Relacionamento 1:N com Cliente
Cliente.hasMany(Pedido, { foreignKey: 'ID_Cliente', onDelete: 'CASCADE' });
Pedido.belongsTo(Cliente, { foreignKey: 'ID_Cliente' });

export default Pedido;