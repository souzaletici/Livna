import { DataTypes } from 'sequelize';
import sequelize from '../assets/config/dataBase.js';

const Produto = sequelize.define('Produto', {
  ID_Produto: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  Nome: { type: DataTypes.STRING(100), allowNull: false },
  Descricao: { type: DataTypes.TEXT },
  Tipo: { type: DataTypes.ENUM('Prata', 'Banhada', 'Pedra sintética') },
  Preco: { type: DataTypes.DECIMAL(10,2), allowNull: false },
  Imagem: { type: DataTypes.STRING(255) },
  Categoria: { type: DataTypes.ENUM('Anel', 'Pulseira', 'Colar', 'Brinco') },
  Quantidade_Estoque: { type: DataTypes.INTEGER, defaultValue: 0 },
});

export default Produto;
