import { sequelize } from '../models/index.js';
import Cliente from '../models/Cliente.js';
import Produto from '../models/Produto.js';
import Pedido from '../models/Pedido.js';
import Pagamento from '../models/Pagamento.js';
import Estoque from '../models/Estoque.js';
import ItemPedido from '../models/ItemEstoque.js';

async function seed() {
  try {
    await sequelize.sync({ force: true });
    console.log('✅ Banco sincronizado!');

    // 1️⃣ Clientes
    const clientes = await Cliente.bulkCreate([
      {
        Nome: 'Maria Silva',
        CPF: '12345678901',
        Email: 'maria@email.com',
        Telefone: '11999999999',
        Cidade: 'São Paulo',
        Estado: 'SP',
        CEP: '01001000'
      },
      {
        Nome: 'João Souza',
        CPF: '98765432100',
        Email: 'joao@email.com',
        Telefone: '21988888888',
        Cidade: 'Rio de Janeiro',
        Estado: 'RJ',
        CEP: '20020000'
      }
    ]);
    console.log('✅ Clientes inseridos!');

    // 2️⃣ Produtos
    const produtos = await Produto.bulkCreate([
      {
        Nome: 'Anel de Prata',
        Descricao: 'Anel delicado de prata 925',
        Tipo: 'Prata',
        Preco: 150.0,
        Categoria: 'Anel',
        Quantidade_Estoque: 10
      },
      {
        Nome: 'Colar Banhado a Ouro',
        Descricao: 'Colar elegante banhado a ouro',
        Tipo: 'Banhada',
        Preco: 200.0,
        Categoria: 'Colar',
        Quantidade_Estoque: 5
      }
    ]);
    console.log('✅ Produtos inseridos!');

    // 3️⃣ Pedidos
    const pedidos = await Pedido.bulkCreate([
      { ID_Cliente: clientes[0].ID_Cliente, Total_Pedido: 350.0, Status: 'Em andamento' },
      { ID_Cliente: clientes[1].ID_Cliente, Total_Pedido: 150.0, Status: 'Em andamento' }
    ]);
    console.log('✅ Pedidos inseridos!');

    // 4️⃣ Pagamentos
    await Pagamento.bulkCreate([
      { ID_Pedido: pedidos[0].ID_Pedido, Metodo_Pagamento: 'Cartão', Status_Pagamento: 'Pago', Valor_Pago: 350.0 },
      { ID_Pedido: pedidos[1].ID_Pedido, Metodo_Pagamento: 'Pix', Status_Pagamento: 'Pendente', Valor_Pago: 150.0 }
    ]);
    console.log('✅ Pagamentos inseridos!');

    // 5️⃣ Estoque
    await Estoque.bulkCreate([
      { ID_Produto: produtos[0].ID_Produto, Quantidade_Disponivel: 10 },
      { ID_Produto: produtos[1].ID_Produto, Quantidade_Disponivel: 5 }
    ]);
    console.log('✅ Estoque atualizado!');

    // 6️⃣ Itens do Pedido
    await ItemPedido.bulkCreate([
      { ID_Pedido: pedidos[0].ID_Pedido, ID_Produto: produtos[0].ID_Produto, Quantidade: 1, Preco_Unitario: produtos[0].Preco },
      { ID_Pedido: pedidos[0].ID_Pedido, ID_Produto: produtos[1].ID_Produto, Quantidade: 1, Preco_Unitario: produtos[1].Preco },
      { ID_Pedido: pedidos[1].ID_Pedido, ID_Produto: produtos[0].ID_Produto, Quantidade: 1, Preco_Unitario: produtos[0].Preco }
    ]);
    console.log('✅ Itens do pedido inseridos!');

    console.log('🎉 Seed finalizado com sucesso!');
    await sequelize.close();
  } catch (error) {
    console.error('❌ Erro ao popular o banco:', error);
  }
}

seed();