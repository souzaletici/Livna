import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

async function criarBanco() {
  try {
    // Conecta sem especificar o banco de dados
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      port: process.env.DB_PORT || 3306,
      user: process.env.DB_USER,
      password: process.env.DB_PASS,
    });

    // Cria o banco de dados se não existir
    await connection.query(`CREATE DATABASE IF NOT EXISTS \`${process.env.DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    await connection.end();
    console.log(`✅ Banco de dados '${process.env.DB_NAME}' verificado/criado com sucesso!`);
    process.exit(0);
  } catch (error) {
    console.error('❌ Erro ao criar o banco de dados:', error.message);
    process.exit(1);
  }
}

criarBanco();
