import express from 'express';
import * as pedidoController from '../controllers/pedidoController.js';

const router = express.Router();

router.get('/', pedidoController.listar);
router.get('/:id', pedidoController.buscarPorId);
router.post('/', pedidoController.criar);
router.put('/:id', pedidoController.atualizar);
router.delete('/:id', pedidoController.excluir);

export default router;