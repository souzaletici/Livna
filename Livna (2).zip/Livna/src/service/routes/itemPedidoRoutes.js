import express from 'express';
import * as itemPedidoController from '../controllers/itemPedidoController.js';

const router = express.Router();

router.get('/', itemPedidoController.listar);
router.get('/:id', itemPedidoController.buscarPorId);
router.post('/', itemPedidoController.criar);
router.put('/:id', itemPedidoController.atualizar);
router.delete('/:id', itemPedidoController.excluir);

export default router;