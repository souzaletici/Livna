import { Pedido, Cliente, Produto, ItemPedido, Pagamento } from '../models/index.js';

export const listar = async (req, res) => {
  try {
    const pedidos = await Pedido.findAll({ include: [Cliente, Pagamento, { model: Produto }] });
    res.json(pedidos);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
};

export const buscarPorId = async (req, res) => {
  try {
    const pedido = await Pedido.findByPk(req.params.id, { include: [Cliente, Pagamento, { model: Produto }] });
    if (!pedido) return res.status(404).json({ erro: 'Pedido não encontrado' });
    res.json(pedido);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
};

export const criar = async (req, res) => {
  try {
    const novo = await Pedido.create(req.body);
    res.status(201).json(novo);
  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
};

export const atualizar = async (req, res) => {
  try {
    const pedido = await Pedido.findByPk(req.params.id);
    if (!pedido) return res.status(404).json({ erro: 'Pedido não encontrado' });
    await pedido.update(req.body);
    res.json(pedido);
  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
};

export const excluir = async (req, res) => {
  try {
    const pedido = await Pedido.findByPk(req.params.id);
    if (!pedido) return res.status(404).json({ erro: 'Pedido não encontrado' });
    await pedido.destroy();
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
};