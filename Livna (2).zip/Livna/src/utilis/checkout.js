const carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
const tbody = document.querySelector('#tabelaCarrinho tbody');
const totalEl = document.getElementById('total');

function formatarPreco(valor) {
    return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function carregarCarrinho() {
    tbody.innerHTML = '';
    let total = 0;
    carrinho.forEach(item => {
        const subtotal = item.preco * item.quantidade;
        total += subtotal;

        const tr = document.createElement('tr');
        tr.innerHTML = `
        <td>${item.nome}</td>
        <td>${item.quantidade}</td>
        <td>${formatarPreco(item.preco)}</td>
        <td>${formatarPreco(subtotal)}</td>
      `;
        tbody.appendChild(tr);
    });
    totalEl.textContent = 'Total: ' + formatarPreco(total);
}

// Validação simples de CPF: remove não-dígitos e exige 11 dígitos
function validarCPF(cpf) {
    if (!cpf) return false;
    const apenasDigitos = cpf.replace(/\D/g, '');
    return apenasDigitos.length === 11;
}

function finalizarCompra() {
    const nome = document.getElementById('nome').value.trim();
    const email = document.getElementById('email').value.trim();
    const telefone = document.getElementById('telefone').value.trim();
    const cpf = document.getElementById('cpf').value.trim();
    const numero = document.getElementById('numero').value.trim();
    const endereco = document.getElementById('endereco').value.trim();
    const complemento = document.getElementById('complemento').value.trim();
    const cidade = document.getElementById('cidade').value.trim();
    const estado = document.getElementById('estado').value;
    const pagamento = document.getElementById('pagamento').value;

    // Campos obrigatórios
    if (!nome || !email || !telefone || !cpf || !numero || !endereco || !cidade || !estado || !pagamento) {
        alert('Preencha todos os campos obrigatórios!');
        return;
    }

    if (!validarCPF(cpf)) {
        alert('CPF inválido. Digite somente os 11 dígitos do CPF.');
        return;
    }

    // Preparar objeto de pedido (aí você envia para o backend)
    const pedido = {
        cliente: { nome, email, telefone, cpf },
        endereco: { endereco, numero, complemento, cidade, estado },
        carrinho,
        pagamento,
        total: carrinho.reduce((s, it) => s + it.preco * it.quantidade, 0),
        data: new Date().toISOString()
    };

    // Exemplo: armazenar no localStorage (apenas para demonstração)
    localStorage.setItem('ultimoPedido', JSON.stringify(pedido));

    // Limpar carrinho
    localStorage.removeItem('carrinho');
    tbody.innerHTML = '';
    totalEl.textContent = '';
    document.getElementById('msgSucesso').textContent =
        `Compra finalizada com sucesso! Obrigado pela preferência, ${nome}!`;

    // (Opcional) você pode redirecionar, exibir número de pedido, etc.
    console.log('Pedido:', pedido);
}

carregarCarrinho();
