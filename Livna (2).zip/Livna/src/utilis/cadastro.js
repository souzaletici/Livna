const form = document.getElementById('form-cadastro');

  form.addEventListener('submit', function(e) {
    e.preventDefault();
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;

    const usuario = { nome, email };
    localStorage.setItem('usuarioLogado', JSON.stringify(usuario));

    alert('Cadastro realizado com sucesso!');
    window.location.href = '../pages/perfil.html';
  });

