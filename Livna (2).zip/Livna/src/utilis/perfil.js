// Carregar informações do usuário
const usuarioLogado = JSON.parse(localStorage.getItem('usuarioLogado'));
if (!usuarioLogado) {
    alert('Você precisa fazer login!');
    window.location.href = 'login.html';
} else {
    document.getElementById('nomeUsuario').textContent = usuarioLogado.nome;
    document.getElementById('emailUsuario').textContent = usuarioLogado.email;
}

// Avatar
const avatarImg = document.getElementById('avatar');
const avatarSalvo = localStorage.getItem('avatarUsuario');
if (avatarSalvo) {
    avatarImg.src = avatarSalvo;
}

function alterarAvatar(event) {
    const arquivo = event.target.files[0];
    if (arquivo) {
        const reader = new FileReader();
        reader.onload = function (e) {
            avatarImg.src = e.target.result;
            localStorage.setItem('avatarUsuario', e.target.result);
        }
        reader.readAsDataURL(arquivo);
    }
}

// Histórico de pedidos
const historico = JSON.parse(localStorage.getItem('historicoPedidos')) || [];
const containerHistorico = document.getElementById('historicoPedidos');

if (historico.length === 0) {
    containerHistorico.innerHTML = '<p class="empty">Você ainda não realizou nenhum pedido.</p>';
} else {
    let tabela = `<table>
      <thead>
        <tr>
          <th>Data</th>
          <th>Itens</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>`;

    historico.forEach(pedido => {
        let itens = pedido.itens.map(i => `${i.quantidade}x ${i.nome}`).join(', ');
        tabela += `<tr>
        <td>${pedido.data}</td>
        <td>${itens}</td>
        <td>${pedido.total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</td>
      </tr>`;
    });

    tabela += '</tbody></table>';
    containerHistorico.innerHTML = tabela;
}

function sair() {
    localStorage.removeItem('usuarioLogado');
    alert('Você saiu da conta.');
    window.location.href = 'login.html';
}