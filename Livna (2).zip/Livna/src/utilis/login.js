const form = document.getElementById('form-login');

form.addEventListener('submit', function (e) {
    e.preventDefault();
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;

    // Salva usuário no localStorage
    const usuario = { nome, email };
    localStorage.setItem('usuarioLogado', JSON.stringify(usuario));

    alert('Login realizado com sucesso!');
    window.location.href = '../pages/perfil.html';
});