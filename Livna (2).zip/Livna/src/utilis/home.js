const produtos = [
    {
        id: 1,
        categoria: "pulseira",
        nome: "Pulseira Luna",
        descricao: "Pulseira de prata leve com corações espelhados.",
        preco: 149.9,
        imagem: "assets/pulseiraLuna.jpg",
    },
    {
        id: 2,
        categoria: "pulseira",
        nome: "Pulseira Angélica",
        descricao: "Pulseira de prata leve riviéria com zircônia cristal quadrada.",
        preco: 189.9,
        imagem: "assets/pulseiraAngelica.jpg",
    },
    {
        id: 3,
        categoria: "colar",
        nome: "Colar Clara",
        descricao: "Colar prata leve com pingente ponto de luz zircônia.",
        preco: 189.9,
        imagem: "assets/colarClara.jpg",
    },
    {
        id: 4,
        categoria: "colar",
        nome: "Colar Ananda",
        descricao: "Colar moderno com pedras.",
        preco: 189.9,
        imagem: "assets/colarAnanda.jpg",
    },
    {
        id: 5,
        categoria: "brinco",
        nome: "Brinco Aurora",
        descricao: "Brinco prata 925 cravejado com zirconias e moissanite.",
        preco: 129.9,
        imagem: "assets/brincoAurora.jpg",
    },
    {
        id: 6,
        categoria: "brinco",
        nome: "Brinco Mariana",
        descricao: "Brinco de prata 925 cravejado com zircônias.",
        preco: 95.50,
        imagem: "assets/brincoMariana.jpg",
    },
    {
        id: 7,
        categoria: "anel",
        nome: "Anel Estela",
        descricao: "Anel de prata 925 com pedra de 2 quilates de moissanite.",
        preco: 159.9,
        imagem: "assets/anelEstela.jpg",
    },
    {
        id: 8,
        categoria: "anel",
        nome: "Anel Livia",
        descricao: "Anel de prata 925 cravejado com zirconias.",
        preco: 259.9,
        imagem: "assets/anelLivia.jpg",
    }
];

const categoriaIdMap = {
    pulseira: "pulseiras",
    colar: "colares",
    brinco: "brincos",
    anel: "aneis"
};

function formatarPreco(valor) {
    return valor.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL",
    });
}

function adicionarAoCarrinho(id) {
    let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];
    const produto = produtos.find((p) => p.id === id);
    if (!produto) return;

    const itemIndex = carrinho.findIndex((item) => item.id === id);
    if (itemIndex > -1) {
        carrinho[itemIndex].quantidade += 1;
    } else {
        carrinho.push({ ...produto, quantidade: 1 });
    }

    localStorage.setItem("carrinho", JSON.stringify(carrinho));
    alert(`Produto "${produto.nome}" adicionado ao carrinho!`);
}

function criarProdutoHTML(produto) {
    const article = document.createElement("article");
    article.className = "produto";
    article.innerHTML = `
          <img src="${produto.imagem}" alt="${produto.nome}" />
          <h3>${produto.nome}</h3>
          <p>${produto.descricao}</p>
          <div class="preco">${formatarPreco(produto.preco)}</div>
          <button onclick="adicionarAoCarrinho(${produto.id})">Adicionar ao Carrinho</button>
        `;
    return article;
}

produtos.forEach((produto) => {
    const containerId = categoriaIdMap[produto.categoria];
    const container = document.getElementById(containerId);
    if (container) {
        container.appendChild(criarProdutoHTML(produto));
    }
});
