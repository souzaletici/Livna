function formatarPreco(valor) {
    return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}
function carregarCarrinho() {
    const carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
    const container = document.getElementById('carrinho-container');

    if (carrinho.length === 0) {
        container.innerHTML = '<p class="empty">Seu carrinho está vazio.</p>';
        return;
    }

    let total = 0;
    let tabela = `<table>
        <thead>
          <tr>
            <th>Produto</th>
            <th>Descrição</th>
            <th>Preço Unitário</th>
            <th>Quantidade</th>
            <th>Subtotal</th>
            <th>Remover</th>
          </tr>
        </thead>
        <tbody>`;

    carrinho.forEach((item, index) => {
        const subtotal = item.preco * item.quantidade;
        total += subtotal;

        tabela += `<tr>
          <td><img src="${item.imagem}" alt="${item.nome}"></td>
          <td>${item.nome}</td>
          <td>${formatarPreco(item.preco)}</td>
          <td>
            <input type="number" min="1" value="${item.quantidade}" onchange="atualizarQuantidade(${index}, this.value)">
          </td>
          <td>${formatarPreco(subtotal)}</td>
          <td><button onclick="removerDoCarrinho(${index})">X</button></td>
        </tr>`;
    });

    tabela += `</tbody></table>
        <div class="total">Total: ${formatarPreco(total)}</div>
        <button class="btn-finalizar" onclick="finalizarCompra()">Finalizar Compra</button>`;

    container.innerHTML = tabela;
}

function atualizarQuantidade(index, novaQtd) {
    let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
    novaQtd = parseInt(novaQtd);
    if (isNaN(novaQtd) || novaQtd < 1) novaQtd = 1;
    carrinho[index].quantidade = novaQtd;
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    carregarCarrinho();
}

function removerDoCarrinho(index) {
    let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
    carrinho.splice(index, 1);
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    carregarCarrinho();
}

function finalizarCompra() {
    if (confirm('Deseja finalizar a compra?')) {
        window.location.href = 'checkout.html';
    }
}

carregarCarrinho();