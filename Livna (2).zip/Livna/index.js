// seed.js
const { sequelize, Cliente, Produto, Pedido, Pagamento, Estoque, ItemPedido } = require("./src/models");
const  express= require ("express");

//import clienteRoutes from './routes/clienteRoutes.js';
const clienteRoutes = require("./src/routes/clienteRoutes.js");
const produtoRoutes = require("./src/routes/produtoRoutes.js");
const pedidoRoutes = require ("./src/routes/pedidoRoutes.js");
const pagamentoRoutes = require ("./src/routes/pagamentoRoutes.js");
const estoqueRoutes = require ("./src/routes/estoqueRoutes.js");
const itemPedidoRoutes = require ("./src/routes/itemPedidoRoutes.js");

async function seed() {
  try {
    await sequelize.sync({ force: true }); // recria todas as tabelas
    console.log('✅ Banco sincronizado!');

    // 1️⃣ Clientes
    const clientes = await Cliente.bulkCreate([
      {
        Nome: 'Maria Silva',
        CPF: '12345678901',
        Email: 'maria@email.com',
        Telefone: '11999999999',
        Cidade: 'São Paulo',
        Estado: 'SP',
        CEP: '01001000',
        Data_Cadastro: '2025-10-21'
      },
      {
        Nome: 'João Souza',
        CPF: '98765432100',
        Email: 'joao@email.com',
        Telefone: '11988888888',
        Cidade: 'Rio de Janeiro',
        Estado: 'RJ',
        CEP: '20020000',
        Data_Cadastro: '2025-10-22'
      }
    ]);
    console.log('✅ Clientes inseridos!');

    // 2️⃣ Produtos
    const produtos = await Produto.bulkCreate([
      {
        Nome: 'Anel de Prata',
        Descricao: 'Anel delicado de prata 925',
        Tipo: 'Prata',
        Preco: 150.0,
        Categoria: 'Anel',
        Quantidade_Estoque: 10
      },
      {
        Nome: 'Colar Banhado a Ouro',
        Descricao: 'Colar elegante banhado a ouro',
        Tipo: 'Banhada',
        Preco: 200.0,
        Categoria: 'Colar',
        Quantidade_Estoque: 5
      }
    ]);
    console.log('✅ Produtos inseridos!');

    // 3️⃣ Pedidos
    const pedidos = await Pedido.bulkCreate([
      {
        ID_Cliente: clientes[0].ID_Cliente,
        Total_Pedido: 350.0,
        Status: 'Em andamento'
      },
      {
        ID_Cliente: clientes[1].ID_Cliente,
        Total_Pedido: 150.0,
        Status: 'Em andamento'
      }
    ]);
    console.log('✅ Pedidos inseridos!');

    // 4️⃣ Pagamentos
    const pagamentos = await Pagamento.bulkCreate([
      {
        ID_Pedido: pedidos[0].ID_Pedido,
        Metodo_Pagamento: 'Cartão',
        Status_Pagamento: 'Pago',
        Valor_Pago: 350.0
      },
      {
        ID_Pedido: pedidos[1].ID_Pedido,
        Metodo_Pagamento: 'Pix',
        Status_Pagamento: 'Pendente',
        Valor_Pago: 150.0
      }
    ]);
    console.log('✅ Pagamentos inseridos!');

    // 5️⃣ Estoque
    await Estoque.bulkCreate([
      {
        ID_Produto: produtos[0].ID_Produto,
        Quantidade_Disponivel: 10,
        Data_Reposicao: '2025-10-21'
      },
      {
        ID_Produto: produtos[1].ID_Produto,
        Quantidade_Disponivel: 5,
        Data_Reposicao: '2025-10-22'
      }
    ]);
    console.log('✅ Estoque atualizado!');

    // 6️⃣ ItensPedido
    await ItemPedido.bulkCreate([
      {
        ID_Pedido: pedidos[0].ID_Pedido,
        ID_Produto: produtos[0].ID_Produto,
        quantidade: 1,
        preco_unitario: produtos[0].Preco
      },
      {
        ID_Pedido: pedidos[0].ID_Pedido,
        ID_Produto: produtos[1].ID_Produto,
        quantidade: 1,
        preco_unitario: produtos[1].Preco
      },
      {
        ID_Pedido: pedidos[1].ID_Pedido,
        ID_Produto: produtos[0].ID_Produto,
        quantidade: 1,
        preco_unitario: produtos[0].Preco
      }
    ]);
    console.log('✅ Itens do pedido inseridos!');

    console.log('🎉 Seed finalizado com sucesso!');
    await sequelize.close();
  } catch (error) {
    console.error('❌ Erro ao popular o banco:', error);
  }
}
// import express from 'express';
import dotenv from 'dotenv';
// import clienteRoutes from './routes/clienteRoutes.js';
// import produtoRoutes from './routes/produtoRoutes.js';
// import pedidoRoutes from './routes/pedidoRoutes.js';
// import pagamentoRoutes from './routes/pagamentoRoutes.js';
// import estoqueRoutes from './routes/estoqueRoutes.js';
// import itemPedidoRoutes from './routes/itemPedidoRoutes.js';

dotenv.config();

const app = express();
app.use(express.json());

// Rotas
app.use('/clientes', clienteRoutes);
app.use('/produtos', produtoRoutes);
app.use('/pedidos', pedidoRoutes);
app.use('/pagamentos', pagamentoRoutes);
app.use('/estoques', estoqueRoutes);
app.use('/itens-pedido', itemPedidoRoutes);

// Porta
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando na porta ${PORT}`);
});
seed();
