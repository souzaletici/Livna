import mysql from "mysql2";

const conexao = mysql.createConnection({
  host: "localhost",      
  user: "livna",          
  password: "escola",    
  database: "semijoias"   
});

conexao.connect((erro) => {
  if (erro) {
    console.error("❌ Erro ao conectar ao MySQL:", erro);
    return;
  }
  console.log("✅ Conectado ao MySQL!");

  const insertSQL = `
    INSERT INTO Cliente (Nome, CPF, Email, Telefone, Cidade, Estado, CEP, Data_Cadastro)
    VALUES (
      'Maria Silva',
      '12345678901',
      'maria@email.com',
      '11999999999',
      'São Paulo',
      'SP',
      '01001000',
      '2025-10-21'
    );
  `;

  conexao.query(insertSQL, (erro, resultado) => {
    if (erro) {
      console.error("❌ Erro ao inserir cliente:", erro);
      return;
    }
    console.log("✅ Cliente inserido com sucesso! ID:", resultado.insertId);


    conexao.query("SELECT * FROM Cliente", (erro, resultados) => {
      if (erro) {
        console.error("❌ Erro ao consultar clientes:", erro);
        return;
      }
      console.log("📦 Clientes cadastrados:");
      console.table(resultados);


      conexao.end((erro) => {
        if (erro) {
          console.error("❌ Erro ao encerrar conexão:", erro);
        } else {
          console.log("🔒 Conexão encerrada com sucesso.");
        }
      });
    });
  });
});
