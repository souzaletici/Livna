import { Estoque, Produto } from '../models/index.js';

export const listar = async (req, res) => {
  try {
    const estoques = await Estoque.findAll({ include: Produto });
    res.json(estoques);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
};

export const buscarPorId = async (req, res) => {
  try {
    const estoque = await Estoque.findByPk(req.params.id, { include: Produto });
    if (!estoque) return res.status(404).json({ erro: 'Registro de estoque não encontrado' });
    res.json(estoque);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
};

export const criar = async (req, res) => {
  try {
    const novo = await Estoque.create(req.body);
    res.status(201).json(novo);
  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
};

export const atualizar = async (req, res) => {
  try {
    const estoque = await Estoque.findByPk(req.params.id);
    if (!estoque) return res.status(404).json({ erro: 'Registro de estoque não encontrado' });
    await estoque.update(req.body);
    res.json(estoque);
  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
};

export const excluir = async (req, res) => {
  try {
    const estoque = await Estoque.findByPk(req.params.id);
    if (!estoque) return res.status(404).json({ erro: 'Registro de estoque não encontrado' });
    await estoque.destroy();
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
};