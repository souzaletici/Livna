import { Pagamento, Pedido } from '../models/index.js';

export const listar = async (req, res) => {
  try {
    const pagamentos = await Pagamento.findAll({ include: Pedido });
    res.json(pagamentos);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
};

export const buscarPorId = async (req, res) => {
  try {
    const pagamento = await Pagamento.findByPk(req.params.id, { include: Pedido });
    if (!pagamento) return res.status(404).json({ erro: 'Pagamento não encontrado' });
    res.json(pagamento);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
};

export const criar = async (req, res) => {
  try {
    const novo = await Pagamento.create(req.body);
    res.status(201).json(novo);
  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
};

export const atualizar = async (req, res) => {
  try {
    const pagamento = await Pagamento.findByPk(req.params.id);
    if (!pagamento) return res.status(404).json({ erro: 'Pagamento não encontrado' });
    await pagamento.update(req.body);
    res.json(pagamento);
  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
};

export const excluir = async (req, res) => {
  try {
    const pagamento = await Pagamento.findByPk(req.params.id);
    if (!pagamento) return res.status(404).json({ erro: 'Pagamento não encontrado' });
    await pagamento.destroy();
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
};