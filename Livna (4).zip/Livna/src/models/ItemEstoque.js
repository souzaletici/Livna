import { DataTypes } from 'sequelize';
import sequelize from '../config/dataBase.js';
import Pedido from './Pedido.js';
import Produto from './Produto.js';

const ItemPedido = sequelize.define('ItemPedido', {
  ID_ItemPedido: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  Quantidade: { type: DataTypes.INTEGER, defaultValue: 1 },
  Preco_Unitario: { type: DataTypes.DECIMAL(10,2) },
});

// Relacionamento M:N Pedido <-> Produto
Pedido.belongsToMany(Produto, { through: ItemPedido, foreignKey: 'ID_Pedido', otherKey: 'ID_Produto' });
Produto.belongsToMany(Pedido, { through: ItemPedido, foreignKey: 'ID_Produto', otherKey: 'ID_Pedido' });

export default ItemPedido;