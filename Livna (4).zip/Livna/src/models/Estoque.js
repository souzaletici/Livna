import { DataTypes } from 'sequelize';
import sequelize from '../config/dataBase.js';
import Produto from './Produto.js';

const Estoque = sequelize.define('Estoque', {
  ID_Estoque: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  Quantidade_Disponivel: { type: DataTypes.INTEGER, defaultValue: 0 },
  Data_Reposicao: { type: DataTypes.DATEONLY }
});

// Relacionamento 1:N com Produto
Produto.hasMany(Estoque, { foreignKey: 'ID_Produto', onDelete: 'CASCADE' });
Estoque.belongsTo(Produto, { foreignKey: 'ID_Produto' });

export default Estoque;