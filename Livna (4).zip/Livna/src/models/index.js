import sequelize from '../config/dataBase.js';  
import Cliente from './Cliente.js';
import Produto from './Produto.js';
import Pedido from './Pedido.js';
import Pagamento from './Pagamento.js';
import Estoque from './Estoque.js';
import ItemPedido from './ItemEstoque.js';

// Relacionamentos
Cliente.hasMany(Pedido, { foreignKey: 'ID_Cliente', onDelete: 'CASCADE' });
Pedido.belongsTo(Cliente, { foreignKey: 'ID_Cliente' });

Pedido.belongsToMany(Produto, { through: ItemPedido, foreignKey: 'ID_Pedido', otherKey: 'ID_Produto' });
Produto.belongsToMany(Pedido, { through: ItemPedido, foreignKey: 'ID_Produto', otherKey: 'ID_Pedido' });

Pedido.hasOne(Pagamento, { foreignKey: 'ID_Pedido', onDelete: 'CASCADE' });
Pagamento.belongsTo(Pedido, { foreignKey: 'ID_Pedido' });

Produto.hasMany(Estoque, { foreignKey: 'ID_Produto', onDelete: 'CASCADE' });
Estoque.belongsTo(Produto, { foreignKey: 'ID_Produto' });

// Exporta todos
export { sequelize, Cliente, Produto, Pedido, Pagamento, Estoque, ItemPedido };