import express from 'express';
import * as estoqueController from '../controllers/estoqueController.js';

const router = express.Router();

router.get('/', estoqueController.listar);
router.get('/:id', estoqueController.buscarPorId);
router.post('/', estoqueController.criar);
router.put('/:id', estoqueController.atualizar);
router.delete('/:id', estoqueController.excluir);

export default router;