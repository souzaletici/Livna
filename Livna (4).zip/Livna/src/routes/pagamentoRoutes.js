import express from 'express';
import * as pagamentoController from '../controllers/pagamentoController.js';

const router = express.Router();

router.get('/', pagamentoController.listar);
router.get('/:id', pagamentoController.buscarPorId);
router.post('/', pagamentoController.criar);
router.put('/:id', pagamentoController.atualizar);
router.delete('/:id', pagamentoController.excluir);

export default router;