<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Finalizar Compra - Loja Livna</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      background-color: #f9f7f6;
      color: #333;
    }

    header {
      background-color: #bfa56a;
      padding: 20px;
      text-align: center;
      color: white;
      font-size: 2rem;
      font-weight: bold;
    }

    main {
      max-width: 800px;
      margin: 30px auto;
      padding: 20px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(191,165,106,0.3);
    }

    h2 {
      color: #bfa56a;
      margin-bottom: 15px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th, td {
      border-bottom: 1px solid #ccc;
      padding: 10px;
      text-align: left;
    }

    .total {
      text-align: right;
      font-weight: bold;
      color: #bfa56a;
      font-size: 1.2rem;
      margin-bottom: 20px;
    }

    .grid-2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }

    input, select {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 1rem;
      box-sizing: border-box;
    }

    button {
      background-color: #bfa56a;
      border: none;
      color: white;
      padding: 12px;
      border-radius: 6px;
      cursor: pointer;
      font-weight: bold;
      font-size: 1rem;
      width: 100%;
    }

    button:hover {
      background-color: #a4884e;
    }

    .msg-sucesso {
      text-align: center;
      color: green;
      font-weight: bold;
      margin-top: 20px;
    }

    nav {
      text-align: right;
      margin-bottom: 20px;
    }

    nav a {
      background-color: #bfa56a;
      color: white;
      padding: 8px 15px;
      text-decoration: none;
      border-radius: 6px;
      font-weight: bold;
    }

    nav a:hover {
      background-color: #a4884e;
    }

    @media (max-width: 600px) {
      .grid-2 { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>

<header>Finalizar Compra</header>

<main>
  <nav>
    <a href="home.html">Voltar à Loja</a>
  </nav>

  <h2>Resumo do Carrinho</h2>
  <table id="tabelaCarrinho">
    <thead>
      <tr>
        <th>Produto</th>
        <th>Qtd</th>
        <th>Preço</th>
        <th>Subtotal</th>
      </tr>
    </thead>
    <tbody></tbody>
  </table>
  <div class="total" id="total"></div>

  <h2>Dados para Entrega</h2>

  <input type="text" id="nome" placeholder="Nome completo">
  <input type="email" id="email" placeholder="Email">
  <input type="tel" id="telefone" placeholder="Telefone (ex: (41) 9XXXX-XXXX)">

  <div class="grid-2">
    <input type="text" id="cpf" placeholder="CPF (somente números)">
    <input type="text" id="numero" placeholder="Número da casa/apto">
  </div>

  <input type="text" id="endereco" placeholder="Endereço (logradouro, bairro)">
  <input type="text" id="complemento" placeholder="Complemento (opcional)">

  <div class="grid-2">
    <input type="text" id="cidade" placeholder="Cidade">
    <select id="estado">
      <option value="">Selecione o estado</option>
      <option value="AC">Acre</option>
      <option value="AL">Alagoas</option>
      <option value="AP">Amapá</option>
      <option value="AM">Amazonas</option>
      <option value="BA">Bahia</option>
      <option value="CE">Ceará</option>
      <option value="DF">Distrito Federal</option>
      <option value="ES">Espírito Santo</option>
      <option value="GO">Goiás</option>
      <option value="MA">Maranhão</option>
      <option value="MT">Mato Grosso</option>
      <option value="MS">Mato Grosso do Sul</option>
      <option value="MG">Minas Gerais</option>
      <option value="PA">Pará</option>
      <option value="PB">Paraíba</option>
      <option value="PR">Paraná</option>
      <option value="PE">Pernambuco</option>
      <option value="PI">Piauí</option>
      <option value="RJ">Rio de Janeiro</option>
      <option value="RN">Rio Grande do Norte</option>
      <option value="RS">Rio Grande do Sul</option>
      <option value="RO">Rondônia</option>
      <option value="RR">Roraima</option>
      <option value="SC">Santa Catarina</option>
      <option value="SP">São Paulo</option>
      <option value="SE">Sergipe</option>
      <option value="TO">Tocantins</option>
    </select>
  </div>

  <h2>Forma de Pagamento</h2>
  <select id="pagamento">
    <option value="">Selecione</option>
    <option value="Cartão de Crédito">Cartão de Crédito</option>
    <option value="Pix">Pix</option>
    <option value="Boleto">Boleto</option>
  </select>

  <button onclick="finalizarCompra()">Finalizar Compra</button>
  <div class="msg-sucesso" id="msgSucesso"></div>
</main>

<script>
  const carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
  const tbody = document.querySelector('#tabelaCarrinho tbody');
  const totalEl = document.getElementById('total');

  function formatarPreco(valor) {
    return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }

  function carregarCarrinho() {
    tbody.innerHTML = '';
    let total = 0;
    carrinho.forEach(item => {
      const subtotal = item.preco * item.quantidade;
      total += subtotal;

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${item.nome}</td>
        <td>${item.quantidade}</td>
        <td>${formatarPreco(item.preco)}</td>
        <td>${formatarPreco(subtotal)}</td>
      `;
      tbody.appendChild(tr);
    });
    totalEl.textContent = 'Total: ' + formatarPreco(total);
  }

  // Validação simples de CPF: remove não-dígitos e exige 11 dígitos
  function validarCPF(cpf) {
    if (!cpf) return false;
    const apenasDigitos = cpf.replace(/\D/g, '');
    return apenasDigitos.length === 11;
  }

  function finalizarCompra() {
    const nome = document.getElementById('nome').value.trim();
    const email = document.getElementById('email').value.trim();
    const telefone = document.getElementById('telefone').value.trim();
    const cpf = document.getElementById('cpf').value.trim();
    const numero = document.getElementById('numero').value.trim();
    const endereco = document.getElementById('endereco').value.trim();
    const complemento = document.getElementById('complemento').value.trim();
    const cidade = document.getElementById('cidade').value.trim();
    const estado = document.getElementById('estado').value;
    const pagamento = document.getElementById('pagamento').value;

    // Campos obrigatórios
    if (!nome || !email || !telefone || !cpf || !numero || !endereco || !cidade || !estado || !pagamento) {
      alert('Preencha todos os campos obrigatórios!');
      return;
    }

    if (!validarCPF(cpf)) {
      alert('CPF inválido. Digite somente os 11 dígitos do CPF.');
      return;
    }

    // Preparar objeto de pedido (aí você envia para o backend)
    const pedido = {
      cliente: { nome, email, telefone, cpf },
      endereco: { endereco, numero, complemento, cidade, estado },
      carrinho,
      pagamento,
      total: carrinho.reduce((s, it) => s + it.preco * it.quantidade, 0),
      data: new Date().toISOString()
    };

    // Exemplo: armazenar no localStorage (apenas para demonstração)
    localStorage.setItem('ultimoPedido', JSON.stringify(pedido));

    // Limpar carrinho
    localStorage.removeItem('carrinho');
    tbody.innerHTML = '';
    totalEl.textContent = '';
    document.getElementById('msgSucesso').textContent =
      `Compra finalizada com sucesso! Obrigado pela preferência, ${nome}!`;

    // (Opcional) você pode redirecionar, exibir número de pedido, etc.
    console.log('Pedido:', pedido);
  }

  carregarCarrinho();
</script>

</body>
</html> 