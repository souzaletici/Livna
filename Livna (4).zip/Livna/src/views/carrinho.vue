<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Carrinho - Livna Joias</title>
  <style>
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin:0; background:#f9f7f6; color:#333; }
    header { background:#bfa56a; padding:20px; text-align:center; color:white; font-size:2.5rem; font-weight:bold; letter-spacing:2px; }
    main { max-width:900px; margin:40px auto; padding:0 20px; }
    table { width:100%; border-collapse:collapse; margin-bottom:20px; }
    th, td { border-bottom:1px solid #ddd; padding:12px 8px; text-align:left; }
    th { background:#bfa56a; color:white; }
    img { width:80px; height:60px; object-fit:cover; border-radius:6px; }
    button { background:#bfa56a; border:none; color:white; padding:6px 12px; border-radius:6px; cursor:pointer; font-weight:bold; transition:0.3s; }
    button:hover { background:#a4884e; }
    nav { margin-bottom:20px; }
    nav a { background:#bfa56a; color:white; padding:8px 15px; text-decoration:none; border-radius:6px; font-weight:bold; }
    nav a:hover { background:#a4884e; }
    .total { font-size:1.4rem; font-weight:bold; text-align:right; margin-bottom:30px; }
    .empty { text-align:center; font-size:1.2rem; color:#777; margin-top:50px; }
    .btn-finalizar { background:#d4af37; color:#fff; padding:12px 24px; border:none; border-radius:8px; font-size:16px; cursor:pointer; display:block; margin-left:auto; }
    .btn-finalizar:hover { background:#b7950b; }
    input[type="number"] { width:60px; text-align:center; }
  </style>
</head>
<body>

<header>Carrinho - Livna Joias</header>

<main>
  <nav>
    <a href="home.html">← Voltar para Loja</a>
  </nav>

  <div id="carrinho-container"></div>
</main>

<script>
function formatarPreco(valor) {
  return valor.toLocaleString('pt-BR', { style:'currency', currency:'BRL' });
}

function carregarCarrinho() {
  const carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
  const container = document.getElementById('carrinho-container');

  if (carrinho.length === 0) {
    container.innerHTML = '<p class="empty">Seu carrinho está vazio.</p>';
    return;
  }

  let total = 0;
  let tabela = `<table>
    <thead>
      <tr>
        <th>Produto</th>
        <th>Descrição</th>
        <th>Preço Unitário</th>
        <th>Quantidade</th>
        <th>Subtotal</th>
        <th>Remover</th>
      </tr>
    </thead>
    <tbody>`;

  carrinho.forEach((item, index) => {
    const subtotal = item.preco * item.quantidade;
    total += subtotal;

    tabela += `<tr>
      <td><img src="${item.imagem}" alt="${item.nome}"></td>
      <td>${item.nome}</td>
      <td>${formatarPreco(item.preco)}</td>
      <td><input type="number" min="1" value="${item.quantidade}" onchange="atualizarQuantidade(${index}, this.value)"></td>
      <td>${formatarPreco(subtotal)}</td>
      <td><button onclick="removerDoCarrinho(${index})">X</button></td>
    </tr>`;
  });

  tabela += `</tbody></table>
    <div class="total">Total: ${formatarPreco(total)}</div>
    <button class="btn-finalizar" onclick="finalizarCompra()">Finalizar Compra</button>`;

  container.innerHTML = tabela;
}

function atualizarQuantidade(index, novaQtd) {
  let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
  novaQtd = parseInt(novaQtd);
  if (isNaN(novaQtd) || novaQtd < 1) novaQtd = 1;
  carrinho[index].quantidade = novaQtd;
  localStorage.setItem('carrinho', JSON.stringify(carrinho));
  carregarCarrinho();
}

function removerDoCarrinho(index) {
  let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
  carrinho.splice(index, 1);
  localStorage.setItem('carrinho', JSON.stringify(carrinho));
  carregarCarrinho();
}

function finalizarCompra() {
  if (confirm('Deseja finalizar a compra?')) {
    window.location.href = 'checkout.html';
  }
}

carregarCarrinho();
</script>

</body>
</html>

