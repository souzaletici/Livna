<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Perfil - Livna Joias</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      background-color: #f9f7f6;
      color: #333;
    }

    .container {
      max-width: 800px;
      margin: 40px auto;
      background-color: white;
      padding: 30px 40px;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(191, 165, 106, 0.3);
      text-align: center;
    }

    h1 {
      color: #bfa56a;
      font-size: 2.2rem;
      margin-bottom: 10px;
    }

    h2 {
      color: #bfa56a;
      margin-top: 40px;
      margin-bottom: 15px;
      border-bottom: 2px solid #bfa56a;
      padding-bottom: 5px;
    }

    .usuario-info p {
      font-size: 1.1rem;
      margin: 8px 0;
    }

    .usuario-info span {
      font-weight: bold;
      color: #555;
    }

    #avatar {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      object-fit: cover;
      border: 3px solid #bfa56a;
      margin-bottom: 15px;
      cursor: pointer;
    }

    input[type="file"] {
      display: none;
    }

    button {
      background-color: #d4af37;
      border: none;
      color: white;
      padding: 12px 24px;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
      margin-top: 20px;
    }

    button:hover {
      background-color: #b7950b;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      border-radius: 8px;
      overflow: hidden;
    }

    th, td {
      padding: 12px 10px;
      text-align: left;
    }

    th {
      background-color: #bfa56a;
      color: white;
    }

    tbody tr:nth-child(even) {
      background-color: #f3f0eb;
    }

    tbody tr:hover {
      background-color: #f1e7d1;
      transition: 0.3s;
    }

    .empty {
      text-align: center;
      color: #777;
      font-style: italic;
      margin-top: 20px;
    }

    nav a {
      display: inline-block;
      margin-top: 20px;
      text-align: center;
      color: #bfa56a;
      text-decoration: none;
      font-weight: bold;
      transition: 0.3s;
    }

    nav a:hover {
      text-decoration: underline;
      color: #a4884e;
    }
  </style>
</head>
<body>

<div class="container">
  <h1>Perfil</h1>

  <!-- Avatar do usuário -->
  <img id="avatar" src="default-avatar.png" alt="Avatar do usuário" onclick="document.getElementById('fileInput').click()">
  <input type="file" id="fileInput" accept="image/*" onchange="alterarAvatar(event)">

  <div class="usuario-info">
    <p><strong>Nome:</strong> <span id="nomeUsuario"></span></p>
    <p><strong>Email:</strong> <span id="emailUsuario"></span></p>
  </div>

  <button onclick="sair()">Sair</button>

  <h2>Histórico de Pedidos</h2>
  <div id="historicoPedidos"></div>

  <nav>
    <a href="home.html">← Voltar à Loja</a>
  </nav>
</div>

<script>
  // Carregar informações do usuário
  const usuarioLogado = JSON.parse(localStorage.getItem('usuarioLogado'));
  if (!usuarioLogado) {
    alert('Você precisa fazer login!');
    window.location.href = 'login.html';
  } else {
    document.getElementById('nomeUsuario').textContent = usuarioLogado.nome;
    document.getElementById('emailUsuario').textContent = usuarioLogado.email;
  }

  // Avatar
  const avatarImg = document.getElementById('avatar');
  const avatarSalvo = localStorage.getItem('avatarUsuario');
  if (avatarSalvo) {
    avatarImg.src = avatarSalvo;
  }

  function alterarAvatar(event) {
    const arquivo = event.target.files[0];
    if (arquivo) {
      const reader = new FileReader();
      reader.onload = function(e) {
        avatarImg.src = e.target.result;
        localStorage.setItem('avatarUsuario', e.target.result);
      }
      reader.readAsDataURL(arquivo);
    }
  }

  // Histórico de pedidos
  const historico = JSON.parse(localStorage.getItem('historicoPedidos')) || [];
  const containerHistorico = document.getElementById('historicoPedidos');

  if (historico.length === 0) {
    containerHistorico.innerHTML = '<p class="empty">Você ainda não realizou nenhum pedido.</p>';
  } else {
    let tabela = `<table>
      <thead>
        <tr>
          <th>Data</th>
          <th>Itens</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>`;

    historico.forEach(pedido => {
      let itens = pedido.itens.map(i => `${i.quantidade}x ${i.nome}`).join(', ');
      tabela += `<tr>
        <td>${pedido.data}</td>
        <td>${itens}</td>
        <td>${pedido.total.toLocaleString('pt-BR', { style:'currency', currency:'BRL' })}</td>
      </tr>`;
    });

    tabela += '</tbody></table>';
    containerHistorico.innerHTML = tabela;
  }

  function sair() {
    localStorage.removeItem('usuarioLogado');
    alert('Você saiu da conta.');
    window.location.href = 'login.html';
  }
</script>

</body>
</html>
