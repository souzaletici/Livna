<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Loja de Joias Livna</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      background-color: #f9f7f6;
      color: #333;
    }

    header {
      background-color: #bfa56a;
      padding: 20px;
      text-align: center;
      color: white;
      font-size: 2.5rem;
      font-weight: bold;
      letter-spacing: 2px;
    }

    main {
      max-width: 1200px;
      margin: 40px auto;
      padding: 0 20px;
    }

    h2.categoria {
      color: #bfa56a;
      margin-bottom: 15px;
    }

    .produtos {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-bottom: 40px;
    }

    .produto {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(191, 165, 106, 0.3);
      padding: 15px;
      text-align: center;
      transition: transform 0.2s ease;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    .produto:hover {
      transform: scale(1.05);
    }

    .produto img {
      max-width: 100%;
      border-radius: 8px;
      height: 180px;
      object-fit: cover;
    }

    .produto h3 {
      margin: 10px 0 5px;
      font-size: 1.2rem;
    }

    .produto p {
      margin: 5px 0 10px;
      color: #777;
      font-size: 1rem;
      flex-grow: 1;
    }

    .preco {
      color: #bfa56a;
      font-weight: bold;
      font-size: 1.1rem;
      margin-bottom: 10px;
    }

    button {
      background-color: #bfa56a;
      border: none;
      color: white;
      padding: 10px;
      border-radius: 6px;
      cursor: pointer;
      font-weight: bold;
      font-size: 1rem;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #a4884e;
    }

    nav {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
    }

    nav a {
      background-color: #bfa56a;
      color: white;
      padding: 8px 15px;
      text-decoration: none;
      border-radius: 6px;
      font-weight: bold;
    }

    nav a:hover {
      background-color: #a4884e;
    }

    footer {
      text-align: center;
      padding: 20px;
      background-color: #bfa56a;
      color: white;
      margin-top: 40px;
    }
  </style>
</head>

<body>

  <header>
    Livna - Joias Exclusivas
  </header>

  <main>
    <nav>
      <a href="perfil.html">👤 Meu Perfil</a>
      <a href="carrinho.html">🛒 Carrinho</a>
    </nav>

    <!-- Seções por categoria -->
    <section id="pulseiras-secao">
      <h2 class="categoria">Pulseiras</h2>
      <div class="produtos" id="pulseiras"></div>
    </section>

    <section id="colares-secao">
      <h2 class="categoria">Colares</h2>
      <div class="produtos" id="colares"></div>
    </section>

    <section id="brincos-secao">
      <h2 class="categoria">Brincos</h2>
      <div class="produtos" id="brincos"></div>
    </section>
  </main>

  <footer>
    &copy; 2025 Livna Joias. Todos os direitos reservados.
  </footer>

  <script>
    const produtos = [
      { 
        id: 1, 
        categoria: "pulseira", 
        nome: "Pulseira Luna", 
        descricao: "Pulseira de prata leve com corações espelhados.", 
        preco: 149.90, 
        imagem: "../src/pulseira_Luna.jpg" 
      },
      { 
        id: 2, 
        categoria: "pulseira", 
        nome: "Pulseira Angélica", 
        descricao: "Pulseira de prata leve riviéria com zircônia cristal quadrada.", 
        preco: 189.90, 
        imagem: "../src/pulseira_Angelica.jpg" 
      },
      { 
        id: 3, 
        categoria: "colar", 
        nome: "Colar Clara", 
        descricao: "Colar prata leve com pingente ponto de luz zircônia.", 
        preco: 189.90, 
        imagem: "../src/colar_Clara.jpg" 
      },
      { 
        id: 4, 
        categoria: "colar", 
        nome: "Colar Ananda", 
        descricao: "Colar moderno com pedras.", 
        preco: 189.90, 
        imagem: "../src/colar_Ananda.jpg" 
      }
    ];

    function formatarPreco(valor) {
      return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    }

    function adicionarAoCarrinho(id) {
      let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
      const produto = produtos.find(p => p.id === id);
      if (!produto) return;

      const itemIndex = carrinho.findIndex(item => item.id === id);
      if (itemIndex > -1) {
        carrinho[itemIndex].quantidade += 1;
      } else {
        carrinho.push({ ...produto, quantidade: 1 });
      }

      localStorage.setItem('carrinho', JSON.stringify(carrinho));
      alert(`Produto "${produto.nome}" adicionado ao carrinho!`);
    }

    function criarProdutoHTML(produto) {
      const article = document.createElement('article');
      article.className = 'produto';
      article.innerHTML = `
        <img src="${produto.imagem}" alt="${produto.nome}" />
        <h3>${produto.nome}</h3>
        <p>${produto.descricao}</p>
        <div class="preco">${formatarPreco(produto.preco)}</div>
        <button onclick="adicionarAoCarrinho(${produto.id})">Adicionar ao Carrinho</button>
      `;
      return article;
    }

    // Renderiza produtos por categoria
    produtos.forEach(produto => {
      const container = document.getElementById(`${produto.categoria}s`);
      if (container) container.appendChild(criarProdutoHTML(produto));
    });
  </script>

</body>
</html>
