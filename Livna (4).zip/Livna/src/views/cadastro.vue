<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro - Livna Joias</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      background-color: #f9f7f6;
      color: #333;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .container {
      background-color: white;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(191, 165, 106, 0.3);
      width: 100%;
      max-width: 400px;
      text-align: center;
    }

    h1 {
      color: #bfa56a;
      margin-bottom: 20px;
    }

    input {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }

    button {
      background-color: #d4af37;
      color: white;
      padding: 12px 24px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
      width: 100%;
    }

    button:hover {
      background-color: #b7950b;
    }

    a {
      display: block;
      margin-top: 15px;
      color: #bfa56a;
      text-decoration: none;
    }

    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="container">
  <h1>Cadastro</h1>
  <form id="form-cadastro">
    <input type="text" id="nome" placeholder="Nome" required>
    <input type="email" id="email" placeholder="Email" required>
    <button type="submit">Cadastrar</button>
  </form>
  <a href="login.html">Já tem conta? Faça login</a>
</div>

<script>
  const form = document.getElementById('form-cadastro');

  form.addEventListener('submit', function(e){
    e.preventDefault();
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;

    // Salva usuário no localStorage
    const usuario = { nome, email };
    localStorage.setItem('usuarioLogado', JSON.stringify(usuario));

    alert('Cadastro realizado com sucesso!');
    window.location.href = 'perfil.html';
  });
</script>

</body>
</html>
